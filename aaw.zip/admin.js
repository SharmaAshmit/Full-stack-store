// Angel Art World - Admin Portal JavaScript
// Handles product CRUD operations, inventory management, and data export/import

// ===== CONFIGURATION =====
const STORAGE_KEY = 'angelArtWorld_products';

// ===== STATE =====
let currentProducts = [];
let editingProductId = null;
let deletingProductId = null;

// ===== UTILITY FUNCTIONS =====

// Generate unique ID
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Get products from localStorage
function getProducts() {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
        try {
            return JSON.parse(stored);
        } catch (e) {
            console.error('Error parsing stored products:', e);
            return [];
        }
    }
    return [];
}

// Save products to localStorage
function saveProducts(products) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
    currentProducts = products;
    renderProductsTable();
    updateDashboardStats();
}

// Get stock status
function getStockStatus(product) {
    if (product.stock === 0) {
        return { status: 'Out of Stock', class: 'bg-red-900/30 text-red-400 border-red-700' };
    } else if (product.stock <= (product.minStock || 0)) {
        return { status: 'Low Stock', class: 'bg-yellow-900/30 text-yellow-400 border-yellow-700' };
    } else {
        return { status: 'In Stock', class: 'bg-green-900/30 text-green-400 border-green-700' };
    }
}

// Get category display name
function getCategoryName(category) {
    const categoryMap = {
        'canvases': 'Professional Canvases',
        'brushes': 'Fine Art Brushes',
        'pigments': 'Pigments & Oils',
        'sketching': 'Sketching Tools'
    };
    return categoryMap[category] || category;
}

// ===== DASHBOARD STATS =====

function updateDashboardStats() {
    const products = currentProducts;
    
    const totalProducts = products.length;
    const inStock = products.filter(p => p.stock > (p.minStock || 0)).length;
    const lowStock = products.filter(p => p.stock > 0 && p.stock <= (p.minStock || 0)).length;
    const outOfStock = products.filter(p => p.stock === 0).length;
    
    document.getElementById('totalProducts').textContent = totalProducts;
    document.getElementById('inStock').textContent = inStock;
    document.getElementById('lowStock').textContent = lowStock;
    document.getElementById('outOfStock').textContent = outOfStock;
}

// ===== PRODUCT TABLE RENDERING =====

function renderProductsTable(filteredProducts = null) {
    const tbody = document.getElementById('productsTableBody');
    const emptyState = document.getElementById('emptyState');
    const products = filteredProducts || currentProducts;
    
    if (products.length === 0) {
        tbody.innerHTML = '';
        emptyState.classList.remove('hidden');
        return;
    }
    
    emptyState.classList.add('hidden');
    
    tbody.innerHTML = products.map(product => {
        const stockStatus = getStockStatus(product);
        return `
            <tr class="hover:bg-noir transition">
                <td class="px-6 py-4 text-sm font-mono text-gray-300">${product.sku}</td>
                <td class="px-6 py-4">
                    <div class="flex items-center">
                        <i data-lucide="${product.icon || 'package'}" class="w-5 h-5 text-gold mr-3"></i>
                        <div>
                            <p class="font-semibold text-white">${product.name}</p>
                            <p class="text-xs text-gray-400">${product.categoryName || getCategoryName(product.category)}</p>
                        </div>
                    </div>
                </td>
                <td class="px-6 py-4 text-sm text-gray-300">${product.categoryName || getCategoryName(product.category)}</td>
                <td class="px-6 py-4 text-sm">
                    <span class="font-semibold ${product.stock === 0 ? 'text-red-400' : product.stock <= (product.minStock || 0) ? 'text-yellow-400' : 'text-green-400'}">
                        ${product.stock} ${product.unit || 'pcs'}
                    </span>
                </td>
                <td class="px-6 py-4">
                    <span class="inline-block px-2 py-1 rounded text-xs font-semibold border ${stockStatus.class}">
                        ${stockStatus.status}
                    </span>
                </td>
                <td class="px-6 py-4">
                    <div class="flex space-x-2">
                        <button onclick="editProduct('${product.id}')" class="text-gold hover:text-gold/80 transition p-1" title="Edit">
                            <i data-lucide="edit" class="w-4 h-4"></i>
                        </button>
                        <button onclick="deleteProduct('${product.id}')" class="text-red-500 hover:text-red-400 transition p-1" title="Delete">
                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
    
    // Re-initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// ===== SEARCH AND FILTER =====

function applyFilters() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const categoryFilter = document.getElementById('categoryFilter').value;
    const stockFilter = document.getElementById('stockFilter').value;
    
    let filtered = [...currentProducts];
    
    // Apply search
    if (searchTerm) {
        filtered = filtered.filter(p => 
            p.name.toLowerCase().includes(searchTerm) || 
            p.sku.toLowerCase().includes(searchTerm)
        );
    }
    
    // Apply category filter
    if (categoryFilter) {
        filtered = filtered.filter(p => p.category === categoryFilter);
    }
    
    // Apply stock filter
    if (stockFilter) {
        filtered = filtered.filter(p => {
            const status = getStockStatus(p);
            switch (stockFilter) {
                case 'in-stock':
                    return status.status === 'In Stock';
                case 'low-stock':
                    return status.status === 'Low Stock';
                case 'out-of-stock':
                    return status.status === 'Out of Stock';
                default:
                    return true;
            }
        });
    }
    
    renderProductsTable(filtered);
}

// ===== MODAL MANAGEMENT =====

function openProductModal(productId = null) {
    const modal = document.getElementById('productModal');
    const modalTitle = document.getElementById('modalTitle');
    const form = document.getElementById('productForm');
    
    editingProductId = productId;
    
    if (productId) {
        // Edit mode
        const product = currentProducts.find(p => p.id === productId);
        if (!product) return;
        
        modalTitle.textContent = 'Edit Product';
        document.getElementById('productId').value = product.id;
        document.getElementById('productName').value = product.name;
        document.getElementById('productSKU').value = product.sku;
        document.getElementById('productCategory').value = product.category;
        document.getElementById('productIcon').value = product.icon || '';
        document.getElementById('productDescription').value = product.description || '';
        document.getElementById('productStock').value = product.stock;
        document.getElementById('productMinStock').value = product.minStock || '';
        document.getElementById('productUnit').value = product.unit || '';
    } else {
        // Add mode
        modalTitle.textContent = 'Add New Product';
        form.reset();
        document.getElementById('productId').value = '';
    }
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeProductModal() {
    const modal = document.getElementById('productModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
    editingProductId = null;
}

// ===== PRODUCT CRUD OPERATIONS =====

function handleProductFormSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const productId = formData.get('id');
    
    const productData = {
        name: formData.get('name'),
        sku: formData.get('sku'),
        category: formData.get('category'),
        categoryName: getCategoryName(formData.get('category')),
        icon: formData.get('icon') || 'package',
        description: formData.get('description') || '',
        stock: parseInt(formData.get('stock')) || 0,
        minStock: parseInt(formData.get('minStock')) || 10,
        unit: formData.get('unit') || 'pcs'
    };
    
    let products = [...currentProducts];
    
    if (productId) {
        // Update existing product
        const index = products.findIndex(p => p.id === productId);
        if (index !== -1) {
            products[index] = { ...products[index], ...productData };
        }
    } else {
        // Add new product
        products.push({
            id: generateId(),
            ...productData
        });
    }
    
    saveProducts(products);
    closeProductModal();
    
    // Show success notification
    showNotification(productId ? 'Product updated successfully!' : 'Product added successfully!', 'success');
}

function editProduct(productId) {
    openProductModal(productId);
}

function deleteProduct(productId) {
    deletingProductId = productId;
    const modal = document.getElementById('deleteModal');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function confirmDelete() {
    if (!deletingProductId) return;
    
    const products = currentProducts.filter(p => p.id !== deletingProductId);
    saveProducts(products);
    closeDeleteModal();
    
    showNotification('Product deleted successfully!', 'success');
}

function closeDeleteModal() {
    const modal = document.getElementById('deleteModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
    deletingProductId = null;
}

// ===== DATA IMPORT/EXPORT =====

function exportData() {
    const data = {
        products: currentProducts,
        exportDate: new Date().toISOString(),
        version: '1.0'
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `angel-art-world-catalog-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification('Data exported successfully!', 'success');
}

function importData(file) {
    const reader = new FileReader();
    
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            
            if (data.products && Array.isArray(data.products)) {
                saveProducts(data.products);
                showNotification('Data imported successfully!', 'success');
            } else {
                showNotification('Invalid data format!', 'error');
            }
        } catch (error) {
            console.error('Import error:', error);
            showNotification('Error importing data!', 'error');
        }
    };
    
    reader.readAsText(file);
}

// ===== NOTIFICATIONS =====

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `fixed top-20 right-6 px-6 py-4 rounded-lg shadow-lg z-50 fade-in ${
        type === 'success' ? 'bg-green-900/90 text-green-200 border border-green-700' : 'bg-red-900/90 text-red-200 border border-red-700'
    }`;
    notification.innerHTML = `
        <div class="flex items-center space-x-3">
            <i data-lucide="${type === 'success' ? 'check-circle' : 'alert-circle'}" class="w-5 h-5"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// ===== EVENT LISTENERS =====

function initEventListeners() {
    // Add product button
    document.getElementById('addProductBtn').addEventListener('click', () => {
        openProductModal();
    });
    
    // Modal close buttons
    document.getElementById('closeModalBtn').addEventListener('click', closeProductModal);
    document.getElementById('cancelBtn').addEventListener('click', closeProductModal);
    
    // Delete modal buttons
    document.getElementById('cancelDeleteBtn').addEventListener('click', closeDeleteModal);
    document.getElementById('confirmDeleteBtn').addEventListener('click', confirmDelete);
    
    // Product form submit
    document.getElementById('productForm').addEventListener('submit', handleProductFormSubmit);
    
    // Export button
    document.getElementById('exportDataBtn').addEventListener('click', exportData);
    
    // Import button
    document.getElementById('importDataBtn').addEventListener('click', () => {
        document.getElementById('importFileInput').click();
    });
    
    document.getElementById('importFileInput').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            importData(file);
        }
        e.target.value = ''; // Reset input
    });
    
    // Search and filter
    document.getElementById('searchInput').addEventListener('input', applyFilters);
    document.getElementById('categoryFilter').addEventListener('change', applyFilters);
    document.getElementById('stockFilter').addEventListener('change', applyFilters);
    
    // Close modals on background click
    document.getElementById('productModal').addEventListener('click', (e) => {
        if (e.target.id === 'productModal') {
            closeProductModal();
        }
    });
    
    document.getElementById('deleteModal').addEventListener('click', (e) => {
        if (e.target.id === 'deleteModal') {
            closeDeleteModal();
        }
    });
}

// ===== INITIALIZATION =====

document.addEventListener('DOMContentLoaded', () => {
    // Load products
    currentProducts = getProducts();
    
    // Render initial state
    renderProductsTable();
    updateDashboardStats();
    
    // Initialize event listeners
    initEventListeners();
    
    // Initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});

// ===== GLOBAL FUNCTIONS (for inline event handlers) =====
window.editProduct = editProduct;
window.deleteProduct = deleteProduct;
