# Angel Art World - Wholesale Website

A high-performance, static website for Angel Art World, a premium artist materials wholesale business in Jammu. Features a dark noir aesthetic with gold accents and includes a complete admin portal for catalog and inventory management.

## 🎨 Features

### Public Website
- **Responsive Design**: Fully mobile-friendly with smooth transitions
- **Dark Noir Aesthetic**: Deep black (#121212) with gold (#D4AF37) accents
- **One-Page Gallery Layout**: Smooth scrolling between sections
- **Product Categories**: Professional Canvases, Fine Art Brushes, Pigments & Oils, Sketching Tools
- **Contact Form**: Clean, dark-themed wholesale inquiry form
- **Real-time Stock Display**: Products automatically show current stock status

### Admin Portal
- **Dashboard Analytics**: Real-time stats for total products, in stock, low stock, and out of stock items
- **Full CRUD Operations**: Add, edit, delete, and manage products
- **Stock Management**: Track quantities with automatic low-stock alerts
- **Search & Filter**: Find products by name, SKU, category, or stock status
- **Data Export/Import**: Backup and restore catalog data in JSON format
- **Responsive Tables**: Mobile-friendly product management interface

## 📁 Project Structure

```
angel-art-world/
├── index.html          # Main public website
├── admin.html          # Admin portal
├── script.js           # Public website JavaScript
├── admin.js            # Admin portal JavaScript
└── README.md           # This file
```

## 🚀 Quick Start

### Option 1: Local Development

1. **Clone or download** all files to a folder
2. Open `index.html` in your web browser
3. Access admin portal via `admin.html` or click "Admin" in navigation

### Option 2: Deploy to GitHub Pages

1. Create a new GitHub repository
2. Upload all files to the repository
3. Go to Settings → Pages
4. Select "Deploy from a branch" → Choose `main` branch → `/ (root)`
5. Click Save
6. Your site will be live at `https://yourusername.github.io/repository-name/`

### Option 3: Deploy to Replit

1. Go to [Replit](https://replit.com/)
2. Create a new Repl → Select "HTML, CSS, JS"
3. Upload all files
4. Click "Run"
5. Your site will be live at the provided Replit URL

### Option 4: Deploy to Netlify

1. Go to [Netlify](https://www.netlify.com/)
2. Drag and drop your project folder
3. Your site will be live instantly with a custom URL

## 🛠️ Technical Stack

- **HTML5**: Semantic markup
- **Tailwind CSS**: Utility-first CSS via CDN
- **Vanilla JavaScript**: No framework dependencies
- **Lucide Icons**: Beautiful, consistent iconography
- **LocalStorage**: Client-side data persistence

## 📝 Usage Guide

### Managing Products (Admin Portal)

#### Adding a New Product

1. Click "Add New Product" button
2. Fill in the required fields:
   - **Product Name**: Display name (e.g., "Premium Cotton Canvas")
   - **SKU**: Unique identifier (e.g., "CAN-001")
   - **Category**: Select from dropdown
   - **Icon**: Lucide icon name (optional, e.g., "layers", "brush", "palette")
   - **Description**: Product details
   - **Stock Quantity**: Current inventory count
   - **Min Stock Alert**: Threshold for low stock warnings
   - **Unit**: Measurement unit (pcs, kg, box, etc.)
3. Click "Save Product"

#### Editing Products

1. Click the edit icon (pencil) next to any product
2. Modify the fields as needed
3. Click "Save Product"

#### Deleting Products

1. Click the delete icon (trash) next to any product
2. Confirm deletion in the popup

#### Searching and Filtering

- **Search Bar**: Type product name or SKU
- **Category Filter**: Show products from specific categories
- **Stock Filter**: Filter by stock status (In Stock, Low Stock, Out of Stock)

#### Data Management

**Export Data**:
- Click "Export Data" to download a JSON backup
- File includes all products and metadata
- Filename includes the current date

**Import Data**:
- Click "Import Data"
- Select a previously exported JSON file
- All products will be restored

### Customization Guide

#### Changing Colors

Edit the Tailwind config in both HTML files:

```javascript
tailwind.config = {
    theme: {
        extend: {
            colors: {
                noir: '#121212',        // Main background
                'noir-light': '#1e1e1e', // Card backgrounds
                'noir-lighter': '#2a2a2a', // Borders
                gold: '#D4AF37',         // Accent color (change to Electric Blue: '#00D4FF')
            }
        }
    }
}
```

#### Modifying Hero Text

In `index.html`, find the hero section and update:

```html
<h2 class="text-5xl md:text-7xl font-display mb-6 leading-tight">
    Your Custom Heading Here.<br>
    <span class="text-gold">Highlighted Text.</span><br>
    Location.
</h2>
```

#### Adding Product Categories

1. Update category options in both `admin.html` form and filters
2. Update `getCategoryName()` function in `admin.js`:

```javascript
function getCategoryName(category) {
    const categoryMap = {
        'canvases': 'Professional Canvases',
        'brushes': 'Fine Art Brushes',
        'pigments': 'Pigments & Oils',
        'sketching': 'Sketching Tools',
        'your-category': 'Your Category Name' // Add here
    };
    return categoryMap[category] || category;
}
```

#### Changing Icons

Browse available icons at [Lucide Icons](https://lucide.dev/icons/)

Use icon names like: `palette`, `brush`, `layers`, `pen-tool`, `package`, etc.

## 🎯 Default Products

The website comes pre-loaded with 4 sample products:

1. **Premium Cotton Canvas** (CAN-001) - 150 in stock
2. **Kolinsky Sable Brush Set** (BRU-001) - 85 in stock
3. **Artist Grade Oil Pigments** (PIG-001) - 220 in stock
4. **Professional Graphite Set** (SKE-001) - 5 in stock (Low Stock Demo)

You can edit or delete these from the admin portal.

## 💾 Data Persistence

All product data is stored in the browser's `localStorage`:

- **Key**: `angelArtWorld_products`
- **Format**: JSON array
- **Persistence**: Data survives page refreshes
- **Limitation**: Data is device/browser specific

For production use, consider integrating with a backend database.

## 📱 Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🔒 Security Notes

This is a **static, client-side application**. Consider these points for production:

1. **No Authentication**: Admin portal is publicly accessible
2. **Client-Side Storage**: Data is stored in browser localStorage
3. **Form Submissions**: Currently simulated (no server backend)

For production deployment:
- Add authentication to admin portal
- Implement server-side API for data storage
- Add HTTPS/SSL certificate
- Implement server-side form handling with email notifications

## 🎨 Design Credits

- **Color Palette**: Custom Dark Noir with Gold accents
- **Typography**: Georgia (serif) for headings, Inter (sans-serif) for body
- **Icons**: Lucide Icons (MIT License)
- **CSS Framework**: Tailwind CSS (MIT License)

## 📄 License

This project is provided as-is for Angel Art World. Feel free to modify and customize as needed.

## 🤝 Support

For customization assistance or feature requests, refer to the inline code comments or contact your developer.

---

**Built with ❤️ for Angel Art World, Jammu**

*Empowering artists with premium materials since [Year]*
